function showPaymentOptions() {
    document.getElementById('homeScreen').style.display = 'none';
    document.getElementById('paymentScreen').style.display = 'block';
    renderPayPalButton();
}

function showHomeScreen() {
    document.getElementById('homeScreen').style.display = 'block';
    document.getElementById('paymentScreen').style.display = 'none';
}

function renderPayPalButton() {
    const amountInput = document.getElementById('donationAmount');
    const paypalContainer = document.getElementById('paypal-button-container');
    
    // Remove any existing PayPal buttons
    paypalContainer.innerHTML = '';
    
    // Render PayPal button
    paypal.Buttons({
        createOrder: function(data, actions) {
            const donationAmount = parseFloat(amountInput.value);
            if (isNaN(donationAmount) || donationAmount <= 0) {
                alert('Please enter a valid donation amount.');
                return;
            }
            return actions.order.create({
                purchase_units: [{
                    amount: {
                        value: donationAmount.toFixed(2)
                    }
                }]
            });
        },
        onApprove: function(data, actions) {
            return actions.order.capture().then(function(details) {
                alert('Thank you for your donation, ' + details.payer.name.given_name + '!');
                showHomeScreen();
            });
        }
    }).render('#paypal-button-container');
}

// Re-render the PayPal button when the amount changes
document.getElementById('donationAmount').addEventListener('input', renderPayPalButton);
